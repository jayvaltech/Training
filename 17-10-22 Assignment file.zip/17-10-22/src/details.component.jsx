import { useParams } from "react-router-dom"
import {BrowserRouter,Routes,Route,NavLink} from "react-router-dom";
import App from "./app";
import data from "./heroes data.json"
let DetailsComp = ()=>{
    let prms = useParams();
    return <div> 
    
        <h1>Details </h1>
        {
            data.heroes.map((val,idx)=>{
                if(val.id == prms.id){
                    return <div>
                            <ul>
                            <h3>
                            <h1>Name : {val.name} <br /></h1>
                            <h2>Power Stats</h2>
                            combat power : {val.powerstats.combat} <br />
                            speed : {val.powerstats.speed} <br />
                            strength : {val.powerstats.strength} <br />
                            <h2>Biography</h2>
                            full-name : {val.biography["full-name"]} <br />
                            place-of-birth : {val.biography["place-of-birth"]} <br />
                            publisher: {val.biography.publisher} <br />
                            budget : {val.biography.budget} <br />
                            <h2>Appearance</h2>
                            gender : {val.appearance.gender} <br />
                            race : {val.appearance.race} <br />
                            height : {val.appearance.height[1]} <br />
                            weight : {val.appearance.weight[1]} <br/>
                            </h3>
                            </ul>
                    </div>
                }
            })
        }

    </div>
}
export default DetailsComp;