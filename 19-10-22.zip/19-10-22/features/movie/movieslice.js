const createSlice = require("@reduxjs/toolkit").createSlice;

const InitialState = {
    numberOfMovies : 0
}

const movieSlice = createSlice({
    name : "Movie",
    initialState : InitialState,
    reducers : {
        addMovie : (state)=> {state.numberOfMovies++} ,
        delMovie : (state)=> {state.numberOfMovies-- }
    }
})

module.exports = movieSlice.reducer;
module.exports.movieActions = movieSlice.actions;