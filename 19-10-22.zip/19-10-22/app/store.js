const  heroReducer =require ("../features/hero/heroslice");
const configureStore=require("@reduxjs/toolkit").configureStore;
const  movieReducer =require ("../features/movie/movieslice");

const store=configureStore({
    reducer:{
        hero:heroReducer,
        movie:movieReducer
    }
})
    
module.exports=store;