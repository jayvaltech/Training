import HomeComp from "./component/home.component";
let App =()=>{
    return <div>
        <p className="header">Avengers List</p>
        <HomeComp/>
    </div>
}
export default App;