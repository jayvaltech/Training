import { useEffect } from "react"
import axios from "axios";
import { useState } from "react";
import "./mystyle.css"
 
let HomeComp = ()=>{
    let [hero, setHeroes] = useState([]);
    // let [nhero, createHero] = useState({ title : '', firstname : '', lastname : ''});
    // let [ehero, modifyHero] = useState({ _id:'', title : '', firstname : '', lastname : ''});
    // let [toggle, toggleHandler] = useState(false);
    let [carthero, modifyCart] = useState({ _id:'', hero : '', name : '', price : 0 ,  instock:true });
    let [qty,updateqty] = useState(0);
 
    let refresh = ()=>{
        axios.get("http://localhost:8080/data").then(res => {
            setHeroes(res.data);
        })
    }
 
    useEffect(function(){
       refresh();
    },[]);

    let clickHandler=(evt)=>{
        updateqty({ quantity:evt.target.value})
    }

    let AddCart=(hid)=>{
        axios.get("http://localhost:8080/gdata/"+hid).then(res => {
            modifyCart(res.data);
        })
            .catch((err)=>{
                console.log("Error",err);
            })
          
    }
    return <div>
                
            <div id="ubox">{
                        hero.map((hero, idx) =>{
                            
                            return <div key={hero._id} className="box">
                                Title : {hero.hero} <br />
                                price : {hero.price} <br />
                                instock:{hero.instock}
                                Quantity <br />
                                <input onChange={(evt)=>{clickHandler(evt)}} type="number" /> &nbsp; &nbsp; 
                                <button onClick={()=>{AddCart(hero._id)}}>Add to cart</button>
                                {/* {console.log(hero._id)} */}
                            </div>
                        })
                    }
                       
                    
                    <div className="cart">
                        name:{carthero.hero} &nbsp; 
                        Quantity:{carthero.quantity} &nbsp;
                        price :{qty.quantity * carthero.price} <br />
                        <button>buy now</button>
                   </div>
                       
                   </div>  
                
            </div>
}
 
export default HomeComp; 
 
 
